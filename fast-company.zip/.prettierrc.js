module.exports = {
    trailingComma: 'none',
    tabWidth: 4,
    semi: true,
    singleQuote: true,
    jsxBracketSameLine: true,
    bracketSpacing: true
};
