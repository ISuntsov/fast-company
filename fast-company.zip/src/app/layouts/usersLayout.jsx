import React from "react";
import Users from "../components/users";

const UsersLayout = () => {
    return (
        <>
            <Users />
        </>
    );
};

export default UsersLayout;
